# Verified test report — Final V6

Tested in the build environment with the user's latest master workbook:
`Secondary & Closing file Nagpur(1).xlsx`

Master verification:
- Rows: 6,039
- HQs: 9
- Stockists: 98
- Unique SKU names: 60
- Embedded master matches the workbook's HQ/customer/SKU/PTS values row-for-row.

PDF backend verification:

| File | HQ / stockist | Rows | SEC | Closing | Auto matched | Review |
|---|---|---:|---:|---:|---:|---:|
| KRUSHNA PHARMA.pdf | AKOLA PL / KRUSHNA PHARMA - AKOLA | 38 | 858 | 761 | 37 | 1 |
| SP SALES.pdf | AKOLA PL / S.P.SALES CORPORATION - AKOLA | 17 | 256 | 456 | 16 | 1 |
| BALAJI AG.pdf | AKOLA PL / BALAJI AGENCIES - AKOLA | 41 | 329 | 466 | 41 | 0 |

Important review cases:
- `ROSUKEM EZ 10` → suggested `ROSUKEM 10MG TABLETS (15'S)` at 82%: review required.
- `VALERA M 500` → suggested `LINAPIL-DM 500 TABLET (10'S)` at 55%: review required; it is not force-matched.

API TestClient verification:
- GET `/api/health` → HTTP 200.
- POST `/api/analyze` for all three PDFs → HTTP 200.
- SEC/Closing totals match the parsed statement totals above.

Frontend static verification:
- Default master is embedded in `index.html`; no `master-data.js` dependency.
- JavaScript syntax check passed.
- Every matched SKU is included in SKU Review.
- Lower-confidence rows do not have their suggested SKU preselected; user must validate them.
- High-confidence rows are preselected but remain editable through the master-SKU dropdown.
