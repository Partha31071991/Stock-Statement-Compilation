# Stock Statement AI Compiler — Vercel Final V6

This is the Vercel-ready build. The default master is embedded directly in `index.html` (6,039 rows), so startup does not depend on fetching `master-template.xlsx`.

## Deploy

Upload the **contents of this folder** to the root of a GitHub repository and import that repository into Vercel. Do not add an extra parent folder.

Required files:
- `index.html`
- `api/index.py`
- `requirements.txt`
- `vercel.json`
- `master-template.xlsx` (reference/default master; not required for startup)

## Verify before testing

Open:
`https://YOUR-DOMAIN/api/health`

Expected:
`{"ok":true,"service":"stock-statement-compiler"}`

The portal itself also shows **API: Online** in the Live Progress card.

## Workflow

1. Default master loads automatically.
2. Upload any number of PDF/XLSX/CSV/TXT stockist statements; the counter shows the number uploaded.
3. HQ and stockist are identified immediately from filename/master data.
4. Process statements individually (concurrent requests).
5. Every extracted SKU appears in SKU Validation.
6. High-confidence matches are preselected; lower-confidence matches require explicit user selection.
7. Every SKU has a master-SKU dropdown for correction.
8. One `Apply All Validated SKUs` button finalizes the mapping.
9. SEC = Sales; Closing = Close; values = PTS × units.
10. Download Excel with MAIN FILE, stockist summary, HQ summary and product analysis.

## File size

Statements are uploaded one at a time to `/api/analyze`. Vercel Functions have a request-body limit, so an individual statement above about 4.4 MB is rejected with a clear message. This does not limit the number of separate statements you can upload.
