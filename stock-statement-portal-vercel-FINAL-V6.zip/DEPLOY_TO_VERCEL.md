# Deploy to Vercel — Final V6

1. Extract this ZIP.
2. Upload the **contents of the extracted folder** to the root of a GitHub repository.
3. Import that repository into Vercel.
4. Use the default Vercel build settings.
5. Deploy.
6. Verify `https://YOUR-DOMAIN/api/health` returns JSON with `ok: true`.
7. Open the main portal and confirm the Live Progress card says `API: Online` and the master status says `Loaded 6,039 bundled master rows`.

Do not open `index.html` with `file://` for production testing. Use the Vercel URL.
